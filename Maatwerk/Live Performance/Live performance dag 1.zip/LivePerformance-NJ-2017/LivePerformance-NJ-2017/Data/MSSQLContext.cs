﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LivePerformance_NJ_2017.Logic;
using System.Data.SqlClient;

namespace LivePerformance_NJ_2017.Data
{
    public class MSSQLContext : IContext
    {
        //GET ALL FROM DATABASE
        public List<Verkiezing> GetAllVerkiezingen()
        {
            List<Verkiezing> result = new List<Verkiezing>();
            using (SqlConnection conn = Database.Connection)
            {
                string query = "SELECT * FROM Verkiezing";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        while (rd.Read())
                        {
                            string Naam = Convert.ToString(rd["Naam"]);
                            DateTime Datum = Convert.ToDateTime(rd["Datum"]);

                            result.Add(new Verkiezing(Naam, Datum));
                        }
                        return result;
                    }
                }
            }
        }

        //laadt alle uitslagen die bij 1 verkiezing horen
        public List<Uitslag> GetUitslagenVoorVerkiezing(int Verkiezing_ID)
        {
            List<Uitslag> result = new List<Uitslag>();
            using (SqlConnection conn = Database.Connection)
            {
                string query = "SELECT p.Naam, u.Stemmen " +
                               "FROM Uitslag u " +
                               "INNER JOIN Partij p ON u.Partij_ID = p.ID " +
                               "INNER JOIN Verkiezing v ON u.Verkiezing_ID = v.ID " +
                               "WHERE v.ID = @Verkiezing_ID ";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Verkiezing_ID", Verkiezing_ID);
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        while (rd.Read())
                        {
                            string PartijNaam = Convert.ToString(rd["Naam"]);
                            int Stemmen = Convert.ToInt32(rd["Stemmen"]);

                            result.Add(new Uitslag(PartijNaam, Stemmen));
                        }

                        return result;
                    }
                }
            }
        }

        public bool InsertVerkiezing(Verkiezing verkiezing)
        {
            using (SqlConnection conn = Database.Connection)
            {
                string query = "INSERT INTO Verkiezing(Naam, Datum)" +
                                "VALUES(@Naam, @Datum)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Naam", verkiezing.Naam);
                    cmd.Parameters.AddWithValue("@Datum", verkiezing.Datum);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
        }

        //GET ITEM BY ID FROM DATABASE
        //public Gerecht GetGerechtByID(int id)
        //{
        //    Gerecht gerecht;
        //    using (SqlConnection conn = Database.Connection)
        //    {
        //        string query = "SELECT * FROM Gerecht WHERE ID = @ID";
        //        using (SqlCommand cmd = new SqlCommand(query, conn))
        //        {
        //            cmd.Parameters.AddWithValue("@ID", id);
        //            using (SqlDataReader rd = cmd.ExecuteReader())
        //            {
        //                while (rd.Read())
        //                {
        //                    int ID = Convert.ToInt32(rd["ID"]);
        //                    string Naam = Convert.ToString(rd["Naam"]);

        //                    gerecht = new Gerecht(ID, Naam);
        //                    return gerecht;
        //                }
        //            }
        //        }
        //        return null;
        //    }
        //}

    }
}
