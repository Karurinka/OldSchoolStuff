﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LivePerformance_NJ_2017.Logic;

namespace LivePerformance_NJ_2017.Data
{
    public interface IContext
    {
        List<Verkiezing> GetAllVerkiezingen();
        List<Uitslag> GetUitslagenVoorVerkiezing(int verkiezing_ID);
        bool InsertVerkiezing(Verkiezing verkiezing);
    }
}
