﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LivePerformance_NJ_2017.Logic
{
    public class Coalitie
    {
        //properties
        public int ID { get; private set; }
        public string Premier { get; private set; }
        private List<Partij> coalitiePartijen = new List<Partij>();

        //constructor

        //methods
        public List<Partij> SelectieMaken(List<Partij> partijen)
        {
            throw new NotImplementedException();
        }

        public string PremierBepalen(Partij partij)
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return "Premier: " + Premier;
        }
    }
}
