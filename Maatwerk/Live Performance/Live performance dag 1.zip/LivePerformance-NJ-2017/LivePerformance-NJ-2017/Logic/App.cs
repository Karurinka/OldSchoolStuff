﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LivePerformance_NJ_2017.Data;
using System.IO;

namespace LivePerformance_NJ_2017.Logic
{
    public class App
    {
        //properties
        public Coalitie Coalitie { get; private set; }
        public Partij Partij { get; private set; }
        public Uitslag Uitslag { get; private set; }
        public Verkiezing Verkiezing { get; private set; }
        private IContext context;
        private List<Uitslag> huidigeCoalitie = new List<Uitslag>();
        private List<Uitslag> huidigePartijen = new List<Uitslag>();
        private List<Verkiezing> alleVerkiezingen = new List<Verkiezing>();

        //constructor
        public App(IContext context)
        {
            this.context = context;
        }

        //methods
        public List<Verkiezing> VerkiezingenOphalen()
        {
            alleVerkiezingen = context.GetAllVerkiezingen();
            return alleVerkiezingen;
        }

        public List<Uitslag> UitslagenOphalen(Verkiezing verkiezing)
        {
            huidigePartijen = context.GetUitslagenVoorVerkiezing(verkiezing.ID);

            foreach (Uitslag u in huidigePartijen)
            {
                // alle stemmen berekenen
                u.BerekenZetelsVoorPartij(verkiezing.BerekenAlleStemmen(huidigePartijen));
                
            }

            return huidigePartijen;
        }

        //insert verkiezing in de database
        public bool VerkiezingInladen(Verkiezing verkiezing)
        {
            if (context.InsertVerkiezing(verkiezing) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //inserten in database
        public bool UitslagInvoeren(Uitslag uitslag)
        {
            throw new NotImplementedException();
        }

        //alle partijen uit de database halen voor die verkiezing
        public List<Partij> OverzichtTonen()
        {
            throw new NotImplementedException();
        }



        //database record updaten
        public Uitslag UitslagAanpassen(Uitslag uitslag)
        {
            throw new NotImplementedException();
        }

        public Coalitie SelectieMaken(List<Partij> partijen)
        {
            throw new NotImplementedException();
        }

        public bool PartijInvoeren(Partij partij)
        {
            throw new NotImplementedException();
        }

        public Partij PartijAanpassen(Partij partij)
        {
            throw new NotImplementedException();
        }

        public void CoalitieExporteren(string filename)
        {
            using (StreamWriter writer = new StreamWriter(filename))
            {
                foreach (Uitslag u in huidigeCoalitie)
                {
                    writer.Write(u.ToString());
                }
            }
        }
    }
}
