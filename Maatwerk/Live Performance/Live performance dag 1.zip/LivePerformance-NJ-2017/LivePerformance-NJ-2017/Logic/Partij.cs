﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LivePerformance_NJ_2017.Logic
{
    public class Partij
    {
        //properties
        public int ID { get; private set; }
        public string Naam { get; private set; }
        public string Lijsttrekker { get; private set; }

        //constructor

        //methods
        public override string ToString()
        {
            return Naam;
        }
    }
}
