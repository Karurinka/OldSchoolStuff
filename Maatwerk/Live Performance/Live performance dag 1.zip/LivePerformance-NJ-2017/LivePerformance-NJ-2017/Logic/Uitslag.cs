﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LivePerformance_NJ_2017.Logic
{
    public class Uitslag
    {
        //properties
        public int ID { get; private set; }
        public int Stemmen { get; private set; }
        public int Zetels { get; private set; }
        public int Partij_ID { get; private set; }
        public string PartijNaam { get; private set; }

        //constructor
        public Uitslag(string partijNaam, int stemmen)
        {
            this.PartijNaam = partijNaam;
            this.Stemmen = stemmen;
        }

        //methods
        public int BerekenZetelsVoorPartij(int allestemmen)
        {
            decimal antwoord;
            antwoord = (decimal)Stemmen / (decimal)allestemmen * 150m;
            Zetels = Convert.ToInt32(antwoord);
            return Zetels;
        }

        public override string ToString()
        {
            return "Partij: " + PartijNaam + " Stemmen: " + Stemmen + " Zetels: " + Zetels;
        }
    }

    public class SorteerUitslagOpStemmen : IComparer<Uitslag>
    {
        public int Compare(Uitslag x, Uitslag y)
        {
            throw new NotImplementedException();
        }
    }

    public class SorteerUitslagOpZetels : IComparer<Uitslag>
    {
        public int Compare(Uitslag x, Uitslag y)
        {
            throw new NotImplementedException();
        }
    }
}
