﻿namespace LivePerformance_NJ_2017
{
    partial class lblCoalitie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbVerkiezingen = new System.Windows.Forms.ListBox();
            this.lblVerkiezingen = new System.Windows.Forms.Label();
            this.btnLaadtVerkiezing = new System.Windows.Forms.Button();
            this.tbNaam = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDatum = new System.Windows.Forms.Label();
            this.tbDatum = new System.Windows.Forms.TextBox();
            this.btnNieuweVerkiezing = new System.Windows.Forms.Button();
            this.lblPartijen = new System.Windows.Forms.Label();
            this.lbUitslagen = new System.Windows.Forms.ListBox();
            this.btnVoegNieuwePartijToe = new System.Windows.Forms.Button();
            this.btnPasPartijAan = new System.Windows.Forms.Button();
            this.btnVoegPartijToeAanCoalitie = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lbCoalitie = new System.Windows.Forms.ListBox();
            this.btnBerekenCoalitie = new System.Windows.Forms.Button();
            this.btnExporteerCoalitie = new System.Windows.Forms.Button();
            this.btnBevestigPartij = new System.Windows.Forms.Button();
            this.lblLijsttrekker = new System.Windows.Forms.Label();
            this.tbLijsttrekker = new System.Windows.Forms.TextBox();
            this.lblPartijNaam = new System.Windows.Forms.Label();
            this.tbPartijNaam = new System.Windows.Forms.TextBox();
            this.lblStemmen = new System.Windows.Forms.Label();
            this.tbStemmen = new System.Windows.Forms.TextBox();
            this.btnBevestig = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbVerkiezingen
            // 
            this.lbVerkiezingen.FormattingEnabled = true;
            this.lbVerkiezingen.Location = new System.Drawing.Point(12, 25);
            this.lbVerkiezingen.Name = "lbVerkiezingen";
            this.lbVerkiezingen.Size = new System.Drawing.Size(220, 95);
            this.lbVerkiezingen.TabIndex = 0;
            // 
            // lblVerkiezingen
            // 
            this.lblVerkiezingen.AutoSize = true;
            this.lblVerkiezingen.Location = new System.Drawing.Point(12, 9);
            this.lblVerkiezingen.Name = "lblVerkiezingen";
            this.lblVerkiezingen.Size = new System.Drawing.Size(71, 13);
            this.lblVerkiezingen.TabIndex = 1;
            this.lblVerkiezingen.Text = "Verkiezingen:";
            // 
            // btnLaadtVerkiezing
            // 
            this.btnLaadtVerkiezing.Location = new System.Drawing.Point(12, 126);
            this.btnLaadtVerkiezing.Name = "btnLaadtVerkiezing";
            this.btnLaadtVerkiezing.Size = new System.Drawing.Size(220, 23);
            this.btnLaadtVerkiezing.TabIndex = 2;
            this.btnLaadtVerkiezing.Text = "Laadt verkiezing";
            this.btnLaadtVerkiezing.UseVisualStyleBackColor = true;
            this.btnLaadtVerkiezing.Click += new System.EventHandler(this.btnLaadtVerkiezing_Click);
            // 
            // tbNaam
            // 
            this.tbNaam.Enabled = false;
            this.tbNaam.Location = new System.Drawing.Point(15, 272);
            this.tbNaam.Name = "tbNaam";
            this.tbNaam.Size = new System.Drawing.Size(217, 20);
            this.tbNaam.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 256);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Naam:";
            // 
            // lblDatum
            // 
            this.lblDatum.AutoSize = true;
            this.lblDatum.Location = new System.Drawing.Point(12, 298);
            this.lblDatum.Name = "lblDatum";
            this.lblDatum.Size = new System.Drawing.Size(41, 13);
            this.lblDatum.TabIndex = 6;
            this.lblDatum.Text = "Datum:";
            // 
            // tbDatum
            // 
            this.tbDatum.Enabled = false;
            this.tbDatum.Location = new System.Drawing.Point(15, 314);
            this.tbDatum.Name = "tbDatum";
            this.tbDatum.Size = new System.Drawing.Size(217, 20);
            this.tbDatum.TabIndex = 5;
            this.tbDatum.Text = "yyyy-mm-dd";
            // 
            // btnNieuweVerkiezing
            // 
            this.btnNieuweVerkiezing.Location = new System.Drawing.Point(12, 155);
            this.btnNieuweVerkiezing.Name = "btnNieuweVerkiezing";
            this.btnNieuweVerkiezing.Size = new System.Drawing.Size(220, 23);
            this.btnNieuweVerkiezing.TabIndex = 7;
            this.btnNieuweVerkiezing.Text = "Nieuwe verkiezing";
            this.btnNieuweVerkiezing.UseVisualStyleBackColor = true;
            this.btnNieuweVerkiezing.Click += new System.EventHandler(this.btnNieuweVerkiezing_Click);
            // 
            // lblPartijen
            // 
            this.lblPartijen.AutoSize = true;
            this.lblPartijen.Location = new System.Drawing.Point(275, 9);
            this.lblPartijen.Name = "lblPartijen";
            this.lblPartijen.Size = new System.Drawing.Size(54, 13);
            this.lblPartijen.TabIndex = 9;
            this.lblPartijen.Text = "Uitslagen:";
            // 
            // lbUitslagen
            // 
            this.lbUitslagen.FormattingEnabled = true;
            this.lbUitslagen.Location = new System.Drawing.Point(275, 25);
            this.lbUitslagen.Name = "lbUitslagen";
            this.lbUitslagen.Size = new System.Drawing.Size(220, 95);
            this.lbUitslagen.TabIndex = 8;
            // 
            // btnVoegNieuwePartijToe
            // 
            this.btnVoegNieuwePartijToe.Location = new System.Drawing.Point(275, 126);
            this.btnVoegNieuwePartijToe.Name = "btnVoegNieuwePartijToe";
            this.btnVoegNieuwePartijToe.Size = new System.Drawing.Size(220, 23);
            this.btnVoegNieuwePartijToe.TabIndex = 10;
            this.btnVoegNieuwePartijToe.Text = "Voeg nieuwe partij toe";
            this.btnVoegNieuwePartijToe.UseVisualStyleBackColor = true;
            this.btnVoegNieuwePartijToe.Click += new System.EventHandler(this.btnVoegNieuwePartijToe_Click);
            // 
            // btnPasPartijAan
            // 
            this.btnPasPartijAan.Location = new System.Drawing.Point(275, 155);
            this.btnPasPartijAan.Name = "btnPasPartijAan";
            this.btnPasPartijAan.Size = new System.Drawing.Size(220, 23);
            this.btnPasPartijAan.TabIndex = 11;
            this.btnPasPartijAan.Text = "Pas partij aan";
            this.btnPasPartijAan.UseVisualStyleBackColor = true;
            // 
            // btnVoegPartijToeAanCoalitie
            // 
            this.btnVoegPartijToeAanCoalitie.Location = new System.Drawing.Point(275, 184);
            this.btnVoegPartijToeAanCoalitie.Name = "btnVoegPartijToeAanCoalitie";
            this.btnVoegPartijToeAanCoalitie.Size = new System.Drawing.Size(220, 23);
            this.btnVoegPartijToeAanCoalitie.TabIndex = 12;
            this.btnVoegPartijToeAanCoalitie.Text = "Voeg partij toe aan coalitie";
            this.btnVoegPartijToeAanCoalitie.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(278, 240);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Coalitie:";
            // 
            // lbCoalitie
            // 
            this.lbCoalitie.FormattingEnabled = true;
            this.lbCoalitie.Location = new System.Drawing.Point(278, 256);
            this.lbCoalitie.Name = "lbCoalitie";
            this.lbCoalitie.Size = new System.Drawing.Size(220, 95);
            this.lbCoalitie.TabIndex = 13;
            // 
            // btnBerekenCoalitie
            // 
            this.btnBerekenCoalitie.Location = new System.Drawing.Point(278, 357);
            this.btnBerekenCoalitie.Name = "btnBerekenCoalitie";
            this.btnBerekenCoalitie.Size = new System.Drawing.Size(220, 23);
            this.btnBerekenCoalitie.TabIndex = 15;
            this.btnBerekenCoalitie.Text = "Bereken coalitie";
            this.btnBerekenCoalitie.UseVisualStyleBackColor = true;
            // 
            // btnExporteerCoalitie
            // 
            this.btnExporteerCoalitie.Location = new System.Drawing.Point(278, 386);
            this.btnExporteerCoalitie.Name = "btnExporteerCoalitie";
            this.btnExporteerCoalitie.Size = new System.Drawing.Size(220, 23);
            this.btnExporteerCoalitie.TabIndex = 16;
            this.btnExporteerCoalitie.Text = "Exporteer coalitie";
            this.btnExporteerCoalitie.UseVisualStyleBackColor = true;
            // 
            // btnBevestigPartij
            // 
            this.btnBevestigPartij.Enabled = false;
            this.btnBevestigPartij.Location = new System.Drawing.Point(520, 155);
            this.btnBevestigPartij.Name = "btnBevestigPartij";
            this.btnBevestigPartij.Size = new System.Drawing.Size(220, 23);
            this.btnBevestigPartij.TabIndex = 21;
            this.btnBevestigPartij.Text = "Bevestig";
            this.btnBevestigPartij.UseVisualStyleBackColor = true;
            // 
            // lblLijsttrekker
            // 
            this.lblLijsttrekker.AutoSize = true;
            this.lblLijsttrekker.Location = new System.Drawing.Point(517, 67);
            this.lblLijsttrekker.Name = "lblLijsttrekker";
            this.lblLijsttrekker.Size = new System.Drawing.Size(61, 13);
            this.lblLijsttrekker.TabIndex = 20;
            this.lblLijsttrekker.Text = "Lijsttrekker:";
            // 
            // tbLijsttrekker
            // 
            this.tbLijsttrekker.Enabled = false;
            this.tbLijsttrekker.Location = new System.Drawing.Point(520, 83);
            this.tbLijsttrekker.Name = "tbLijsttrekker";
            this.tbLijsttrekker.Size = new System.Drawing.Size(217, 20);
            this.tbLijsttrekker.TabIndex = 19;
            // 
            // lblPartijNaam
            // 
            this.lblPartijNaam.AutoSize = true;
            this.lblPartijNaam.Location = new System.Drawing.Point(517, 25);
            this.lblPartijNaam.Name = "lblPartijNaam";
            this.lblPartijNaam.Size = new System.Drawing.Size(38, 13);
            this.lblPartijNaam.TabIndex = 18;
            this.lblPartijNaam.Text = "Naam:";
            // 
            // tbPartijNaam
            // 
            this.tbPartijNaam.Enabled = false;
            this.tbPartijNaam.Location = new System.Drawing.Point(520, 41);
            this.tbPartijNaam.Name = "tbPartijNaam";
            this.tbPartijNaam.Size = new System.Drawing.Size(217, 20);
            this.tbPartijNaam.TabIndex = 17;
            // 
            // lblStemmen
            // 
            this.lblStemmen.AutoSize = true;
            this.lblStemmen.Location = new System.Drawing.Point(517, 106);
            this.lblStemmen.Name = "lblStemmen";
            this.lblStemmen.Size = new System.Drawing.Size(54, 13);
            this.lblStemmen.TabIndex = 23;
            this.lblStemmen.Text = "Stemmen:";
            // 
            // tbStemmen
            // 
            this.tbStemmen.Enabled = false;
            this.tbStemmen.Location = new System.Drawing.Point(520, 122);
            this.tbStemmen.Name = "tbStemmen";
            this.tbStemmen.Size = new System.Drawing.Size(217, 20);
            this.tbStemmen.TabIndex = 22;
            // 
            // btnBevestig
            // 
            this.btnBevestig.Enabled = false;
            this.btnBevestig.Location = new System.Drawing.Point(15, 340);
            this.btnBevestig.Name = "btnBevestig";
            this.btnBevestig.Size = new System.Drawing.Size(220, 23);
            this.btnBevestig.TabIndex = 24;
            this.btnBevestig.Text = "Bevestig";
            this.btnBevestig.UseVisualStyleBackColor = true;
            this.btnBevestig.Click += new System.EventHandler(this.btnBevestig_Click);
            // 
            // lblCoalitie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 423);
            this.Controls.Add(this.btnBevestig);
            this.Controls.Add(this.lblStemmen);
            this.Controls.Add(this.tbStemmen);
            this.Controls.Add(this.btnBevestigPartij);
            this.Controls.Add(this.lblLijsttrekker);
            this.Controls.Add(this.tbLijsttrekker);
            this.Controls.Add(this.lblPartijNaam);
            this.Controls.Add(this.tbPartijNaam);
            this.Controls.Add(this.btnExporteerCoalitie);
            this.Controls.Add(this.btnBerekenCoalitie);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbCoalitie);
            this.Controls.Add(this.btnVoegPartijToeAanCoalitie);
            this.Controls.Add(this.btnPasPartijAan);
            this.Controls.Add(this.btnVoegNieuwePartijToe);
            this.Controls.Add(this.lblPartijen);
            this.Controls.Add(this.lbUitslagen);
            this.Controls.Add(this.btnNieuweVerkiezing);
            this.Controls.Add(this.lblDatum);
            this.Controls.Add(this.tbDatum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbNaam);
            this.Controls.Add(this.btnLaadtVerkiezing);
            this.Controls.Add(this.lblVerkiezingen);
            this.Controls.Add(this.lbVerkiezingen);
            this.Name = "lblCoalitie";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbVerkiezingen;
        private System.Windows.Forms.Label lblVerkiezingen;
        private System.Windows.Forms.Button btnLaadtVerkiezing;
        private System.Windows.Forms.TextBox tbNaam;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDatum;
        private System.Windows.Forms.TextBox tbDatum;
        private System.Windows.Forms.Button btnNieuweVerkiezing;
        private System.Windows.Forms.Label lblPartijen;
        private System.Windows.Forms.ListBox lbUitslagen;
        private System.Windows.Forms.Button btnVoegNieuwePartijToe;
        private System.Windows.Forms.Button btnPasPartijAan;
        private System.Windows.Forms.Button btnVoegPartijToeAanCoalitie;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lbCoalitie;
        private System.Windows.Forms.Button btnBerekenCoalitie;
        private System.Windows.Forms.Button btnExporteerCoalitie;
        private System.Windows.Forms.Button btnBevestigPartij;
        private System.Windows.Forms.Label lblLijsttrekker;
        private System.Windows.Forms.TextBox tbLijsttrekker;
        private System.Windows.Forms.Label lblPartijNaam;
        private System.Windows.Forms.TextBox tbPartijNaam;
        private System.Windows.Forms.Label lblStemmen;
        private System.Windows.Forms.TextBox tbStemmen;
        private System.Windows.Forms.Button btnBevestig;
    }
}

