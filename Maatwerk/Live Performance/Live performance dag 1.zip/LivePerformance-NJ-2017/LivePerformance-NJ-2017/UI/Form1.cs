﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LivePerformance_NJ_2017.Data;
using LivePerformance_NJ_2017.Logic;

namespace LivePerformance_NJ_2017
{
    public partial class lblCoalitie : Form
    {
        private App app;

        public lblCoalitie(IContext context)
        {
            InitializeComponent();
            app = new App(context);
            ReloadForm();
        }

        public void ReloadForm()
        {
            foreach (Verkiezing v in app.VerkiezingenOphalen())
            {
                lbVerkiezingen.Items.Add(v);
            }
        }

        private void btnNieuweVerkiezing_Click(object sender, EventArgs e)
        {
            tbNaam.Enabled = true;
            tbDatum.Enabled = true;
            btnBevestig.Enabled = true;
        }

        private void btnLaadtVerkiezing_Click(object sender, EventArgs e)
        {
            if (lbVerkiezingen.SelectedItem != null)
            {
                Verkiezing verkiezing = lbVerkiezingen.SelectedItem as Verkiezing;

                foreach (Uitslag u in app.UitslagenOphalen(verkiezing))
                {
                    lbUitslagen.Items.Add(u);
                }
            }
        }

        private void btnVoegNieuwePartijToe_Click(object sender, EventArgs e)
        {
            Verkiezing verkiezing = lbVerkiezingen.SelectedItem as Verkiezing;

            tbPartijNaam.Enabled = true;
            tbLijsttrekker.Enabled = true;
            tbStemmen.Enabled = true;

            btnBevestigPartij.Enabled = true;
        }

        private void btnBevestig_Click(object sender, EventArgs e)
        {
            string naam = tbNaam.Text;
            DateTime datum = Convert.ToDateTime(tbDatum.Text);

            try
            {
                app.VerkiezingInladen(new Verkiezing(naam, datum));
            }
            catch (Exception)
            {
                MessageBox.Show("Er is een fout opgetreden bij het toe voegen van een verkiezing aan de database");
            }
            ReloadForm();
        }
    }
}
