--Drop tables
DROP TABLE Uitslag
DROP TABLE Coalitie_Partij
DROP TABLE Coalitie
DROP TABLE Partij
DROP TABLE Verkiezing

--Create tables
CREATE TABLE Verkiezing(
ID int IDENTITY(1,1) PRIMARY KEY,
Naam varchar(40) UNIQUE NOT NULL,
Datum date UNIQUE NOT NULL
);

CREATE TABLE Partij(
ID int PRIMARY KEY,
Naam varchar(40) NOT NULL,
Lijsttrekker varchar(60) NOT NULL
);

CREATE TABLE Coalitie(
ID int PRIMARY KEY,
Premier varchar(60) NOT NULL
);

CREATE TABLE Coalitie_Partij(
Coalitie_ID int FOREIGN KEY REFERENCES Coalitie(ID),
Partij_ID int FOREIGN KEY REFERENCES Partij(ID)
);

CREATE TABLE Uitslag(
ID int PRIMARY KEY,
Verkiezing_ID int FOREIGN KEY REFERENCES Verkiezing(ID),
Partij_ID int FOREIGN KEY REFERENCES Partij(ID),
Stemmen int NOT NULL,
Zetels int
);

--Inserts
--Verkiezing
INSERT INTO Verkiezing(Naam, Datum)
VALUES('Provinciale Staten Gelderland', GETDATE() +1);
INSERT INTO Verkiezing(Naam, Datum)
VALUES('Provinciale Staten Overijssel', GETDATE() -1);

--Partij
INSERT INTO Partij(ID, Naam, Lijsttrekker)
VALUES(1, 'PVDA', 'Piet');
INSERT INTO Partij(ID, Naam, Lijsttrekker)
VALUES(2, 'D66', 'Henk');
INSERT INTO Partij(ID, Naam, Lijsttrekker)
VALUES(3, 'SP', 'Ernst');
INSERT INTO Partij(ID, Naam, Lijsttrekker)
VALUES(4, 'VVD', 'Bob');
INSERT INTO Partij(ID, Naam, Lijsttrekker)
VALUES(5, 'Ouderen Ehv', 'Jan');
INSERT INTO Partij(ID, Naam, Lijsttrekker)
VALUES(6, 'CDA', 'Tim');
INSERT INTO Partij(ID, Naam, Lijsttrekker)
VALUES(7, 'GL', 'Dennis');
INSERT INTO Partij(ID, Naam, Lijsttrekker)
VALUES(8, 'Leefbaar Ehv', 'Simon');
INSERT INTO Partij(ID, Naam, Lijsttrekker)
VALUES(9, 'LPF Ehv', 'Roel');
INSERT INTO Partij(ID, Naam, Lijsttrekker)
VALUES(10, 'CU', 'Luc');


--Coalitie
INSERT INTO Coalitie(ID, Premier)
VALUES(1, 'Piet');

--Coalitie_Partij
INSERT INTO Coalitie_Partij(Coalitie_ID, Partij_ID)
VALUES(1, 1);
INSERT INTO Coalitie_Partij(Coalitie_ID, Partij_ID)
VALUES(1, 2);
INSERT INTO Coalitie_Partij(Coalitie_ID, Partij_ID)
VALUES(1, 3);

--Uitslag
INSERT INTO Uitslag(ID, Verkiezing_ID, Partij_ID, Stemmen, Zetels)
VALUES(1, 1, 1, 12451, 0)
INSERT INTO Uitslag(ID, Verkiezing_ID, Partij_ID, Stemmen, Zetels)
VALUES(2, 1, 2, 11482, 0);
INSERT INTO Uitslag(ID, Verkiezing_ID, Partij_ID, Stemmen, Zetels)
VALUES(3, 1, 3, 11368, 0);

--Select statements
SELECT p.Naam, u.Stemmen
FROM Uitslag u
INNER JOIN Partij p ON u.Partij_ID = p.ID
INNER JOIN Verkiezing v ON u.Verkiezing_ID = v.ID
WHERE v.ID = 1;