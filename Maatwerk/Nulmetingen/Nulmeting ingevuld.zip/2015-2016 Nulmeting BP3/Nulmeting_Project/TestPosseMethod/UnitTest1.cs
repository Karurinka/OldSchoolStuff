﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using _2015_NJ_SE2_BP3H_OO_Programma;
using System.Collections.Generic;

namespace TestPosseMethod
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_if_posse_method_works_with_previous_information()
        {
            // Arrange
            Administratie administratie = new Administratie();

            String GemeenteNaam = "Alkmaar";
            String Provincie = "Noord - Holland";
            int x = 5821;
            int y =328;
            int aantal = 10710;

            administratie.VoegToe(GemeenteNaam, Provincie, x, y, aantal);

            Provincie provincie = new Provincie("provincieNaam");
            Gemeente gemeente = new Gemeente("gemeenteNaam", provincie, 12000, 100, 100);
            List<CadeauType> cadeauTypes = new List<CadeauType>();
            
            
            // Act
            cadeauTypes.Add(CadeauType.Digitaal);
            cadeauTypes.Add(CadeauType.Educatief);
            cadeauTypes.Add(CadeauType.Gedicht);
            cadeauTypes.Add(CadeauType.Speelgoed);

            List<Piet> posseVoorstel = administratie.StelPosseSamen(gemeente, cadeauTypes);

            // Assert
            Assert.IsNotNull(posseVoorstel);
            CollectionAssert.AllItemsAreUnique(posseVoorstel);

            // Controleer of de Posse voor gemeente 
        }
    }
}
