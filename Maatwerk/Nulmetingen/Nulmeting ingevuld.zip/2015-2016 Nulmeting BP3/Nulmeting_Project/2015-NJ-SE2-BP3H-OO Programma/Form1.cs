﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2015_NJ_SE2_BP3H_OO_Programma
{
    public partial class Form1 : Form
    {
        Administratie administratie;
        Provincie selectedProvincie;
        Gemeente selectedGemeente;

        string gemeente;
        string provincie;
        int x;
        int y;
        int aantalkinderen;
        public Form1()
        {
            InitializeComponent();
            administratie = new Administratie();
            ReloadForm();
        }

        public void ReloadForm()
        {
            Import();

            foreach(Gemeente g in administratie.Gemeentes)
            {
                lbGemeenten.Items.Add(g.ToString());
            }

            foreach (Provincie p in administratie.Provincies)
            {
                lbProvincies.Items.Add(p.ToString());
            }
        }

        public Gemeente GetAllGemeentes(string parameters)
        {
            Gemeente ret = null;
            string[] splitParameters = parameters.Split(';');

            gemeente = splitParameters[0];
            provincie = splitParameters[1];
            x = Convert.ToInt32(splitParameters[2]);
            y = Convert.ToInt32(splitParameters[3]);
            aantalkinderen = Convert.ToInt32(splitParameters[4]);

            return ret = new Gemeente(gemeente, provincie, aantalkinderen, x, y);
        }

        private void Import()
        {
            string path = "coordinaten.csv";
            using (StreamReader reader = new StreamReader(path))
            {
                List<string> importedLines = new List<string>();
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    importedLines.Add(line);
                }

                foreach (string s in importedLines)
                {
                    try
                    {
                        administratie.Gemeentes.Add(GetAllGemeentes(s));
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void lbProvincies_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbProvincies.SelectedIndex != -1)
            {
                foreach (Gemeente gemeente in administratie.Gemeentes)
                {
                    lbGemeenten.Items.Add(gemeente);
                    if (gemeente.Naam == "Meppel")
                    {
                        administratie.ThuisBasis = gemeente;
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecteer eerst een provincie");
            }
        }

        private void btnMaakPosse_Click(object sender, EventArgs e)
        {
            lbPosse.Items.Clear();
            List<CadeauType> cadeauTypeList = new List<CadeauType>();
            selectedGemeente = (Gemeente)lbGemeenten.SelectedItem;

            if (selectedGemeente != null)
            {
                if (chkDigitaal.Checked)
                {
                    cadeauTypeList.Add(CadeauType.Digitaal);
                    administratie.StelPosseSamen(selectedGemeente, cadeauTypeList);


                    foreach (Piet piet in administratie.StelPosseSamen(selectedGemeente, cadeauTypeList))
                    {
                        lbPosse.Items.Add("Piet vaardigheid: " + piet.ToString() + " aantal + 1");
                    }
                }
                if (chkEducatief.Checked)
                {
                    cadeauTypeList.Add(CadeauType.Educatief);
                    administratie.StelPosseSamen(selectedGemeente, cadeauTypeList);


                    foreach (Piet piet in administratie.StelPosseSamen(selectedGemeente, cadeauTypeList))
                    {
                        lbPosse.Items.Add("Piet vaardigheid: " + piet.ToString() + " aantal + 1");
                    }
                }
                if (chkGedicht.Checked)
                {
                    cadeauTypeList.Add(CadeauType.Gedicht);
                    administratie.StelPosseSamen(selectedGemeente, cadeauTypeList);

                    foreach (Piet piet in administratie.StelPosseSamen(selectedGemeente, cadeauTypeList))
                    {
                        lbPosse.Items.Add("Piet vaardigheid: " + piet.ToString() + " aantal + 1");
                    }
                }
                if (chkSpeelgoed.Checked)
                {
                    cadeauTypeList.Add(CadeauType.Speelgoed);
                    administratie.StelPosseSamen(selectedGemeente, cadeauTypeList);


                    foreach (Piet piet in administratie.StelPosseSamen(selectedGemeente, cadeauTypeList))
                    {
                        lbPosse.Items.Add("Piet vaardigheid: " + piet.ToString() + " aantal + 1");
                    }
                }

                // Telt de totale pieten bij elkaar op. Dit geeft een beter overzicht.
                lbPosse.Items.Add("Aantal pieten nodig: " + lbPosse.Items.Count.ToString());

            }
            else
            {
                MessageBox.Show("Selecteer eerst een gemeente");
            }
        }
    }
}
