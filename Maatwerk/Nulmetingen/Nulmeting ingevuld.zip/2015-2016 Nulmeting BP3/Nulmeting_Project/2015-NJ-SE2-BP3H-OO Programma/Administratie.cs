﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace _2015_NJ_SE2_BP3H_OO_Programma
{ 
//    TODO: voor je indient schrijf je hier kort op hoe je denkt dat het gegaan is:
//- Overerving van Pieten geïmplementeerd: Ik heb voor een groot deel het implementeren
//    van de pieten kunnen doen.
//- Importeren van gemeentes uit bestand is af: Ik heb dit voor een groot deel af,
//    maar loop op het probleem dat ik deze niet kan testen omdat er al veel errors
//	in de stelPosseSamen methode zitten.Ik heb uiteindelijk deze code uitgecomment om
//    de streamreader te testen en toen deed deze het wel.
//- Verbeterende fouten om programma werkende te krijgen:
//	1) Ik heb het importeren van de csv verplaatst.
//  2) Ik heb een paar kleine aanpassingen in de Piet klasses aangebracht
//- Refactoring Form1.cs>btnMaakPosse_Click: Ik ben hier niet aan toegekomen
//- TestPosseMethod test is volledig: Ik heb nog steeds moeite met unit tests omdat ik voor
//    mijn gevoel niet echt veel uitleg van heb gekregen en heb ook nog nooit echt een
//    unit test gemaakt.
//- StelPosseSamen is verbeterd: Ik ben hier niet aan toegekomen
//- Andere verbeteringen die je zou aanbrengen in deze code: De veld gemeente of provincie een
//    veld maken in een van de twee klasses.


    public class Administratie
    {
        // Fields
        private Gemeente thuisBasis;
        private List<Gemeente> gemeentes = new List<Gemeente>();
        private List<Provincie> provincies = new List<Provincie>();

        // Propertys
        public Gemeente ThuisBasis
        {
            get { return thuisBasis; }
            set { thuisBasis = value; }
        }

        public List<Gemeente> Gemeentes
        {
            get { return gemeentes; }
            set { gemeentes = value; }
        }

        public List<Provincie> Provincies
        {
            get { return provincies; }
            set { provincies = value; }

        }

        // Constructor
        public Administratie()
        {

        }

        /// <summary>
        /// 
        /// 
        /// </summary>
        /// <param name="gemeente"></param>
        /// <param name="provincie"></param>
        /// <param name="aantalKinderen"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void VoegToe(string gemeente, string provincie, int aantalKinderen, int x, int y)
        {
            Provincie p = ZoekProvincieOpNaam(provincie);
            Gemeente m = null; // TODO maak gemeente
            p.VoegGemeenteToe(m);
        }

        public Provincie ZoekProvincieOpNaam(string provincie)
        {
            Provincie p = null;

            // TODO zoek een provincie uit de lijst met bestaande provincies die de naam <provincie> heeft
            // en wijs deze toe aan p.

            if (p == null)
            {
                // TODO maak een nieuwe provincie met naam <provincie>

                // TODO voeg deze provincie toe aan de lijst
            }

            return p;
        }

        public List<Piet> StelPosseSamen(String provincie, String gemeente_naam, List<CadeauType> cadeauTypes)
        {
            Gemeente gemeente = ZoekProvincieOpNaam(provincie).ZoekGemeente(gemeente_naam);

            // TODO Hieronder staat een weinig effectieve manier om de Posse op te stellen. 
            // Je hoeft hem niet te herschrijven, maar eventueel wel te verbeteren als er een bug zou inzitten.

            // Aanmaken van piet objecten.
            // Aanmaken van een piet lijst om de benodigde pieten in op te slaan en een lijst met cadeautypes om de verschilende cadeaus in op te slaan.
            WegwijsPiet wegWijsPiet;
            OnhandigePiet onhandigePiet;
            SlimmePiet slimmePiet;
            CoolePiet coolePiet;
            List<Piet> pietenLijst = new List<Piet>();
            // Controleren of de afstand van het geselecteerde gemeente groter dan 25 km bedraagt (vanaf de thuisbasis).
            //if (gemeente.AfstandTot(gemeente) > 25)
            //{
            wegWijsPiet = new WegwijsPiet();

            // Als er meer dan 10000 kinderen aanwezig zijn, dan worden de pieten verdubbeld.
            if (gemeente.AantalKinderen > 10000)
            {
                if (cadeauTypes.Contains(CadeauType.Gedicht))
                {
                    coolePiet = new CoolePiet();
                    CoolePiet coolePietReserve = new CoolePiet();

                    pietenLijst.Add(coolePiet);
                    pietenLijst.Add(coolePietReserve);
                    cadeauTypes.Add(CadeauType.Gedicht);
                }
                if (cadeauTypes.Contains(CadeauType.Digitaal))
                {
                    slimmePiet = new SlimmePiet();
                    SlimmePiet slimmePietReserve = new SlimmePiet();

                    pietenLijst.Add(slimmePiet);
                    pietenLijst.Add(slimmePietReserve);
                    cadeauTypes.Add(CadeauType.Digitaal);
                }
                if (cadeauTypes.Contains(CadeauType.Speelgoed))
                {
                    onhandigePiet = new OnhandigePiet();
                    OnhandigePiet onhandigePietReserver = new OnhandigePiet();

                    pietenLijst.Add(onhandigePiet);
                    pietenLijst.Add(onhandigePietReserver);
                    cadeauTypes.Add(CadeauType.Speelgoed);
                }
                if (cadeauTypes.Contains(CadeauType.Educatief))
                {
                    onhandigePiet = new OnhandigePiet();
                    slimmePiet = new SlimmePiet();

                    OnhandigePiet onhandigePietReserve = new OnhandigePiet();
                    SlimmePiet slimmePietReserve = new SlimmePiet();

                    pietenLijst.Add(onhandigePiet);
                    pietenLijst.Add(slimmePiet);
                    pietenLijst.Add(onhandigePietReserve);
                    pietenLijst.Add(slimmePietReserve);
                    cadeauTypes.Add(CadeauType.Educatief);
                }
            }
            else
            {
                if (cadeauTypes.Contains(CadeauType.Gedicht))
                {
                    coolePiet = new CoolePiet();

                    pietenLijst.Add(coolePiet);
                    cadeauTypes.Add(CadeauType.Gedicht);
                }
                if (cadeauTypes.Contains(CadeauType.Digitaal))
                {
                    slimmePiet = new SlimmePiet();

                    pietenLijst.Add(slimmePiet);
                    cadeauTypes.Add(CadeauType.Digitaal);
                }
                if (cadeauTypes.Contains(CadeauType.Speelgoed))
                {
                    onhandigePiet = new OnhandigePiet();

                    pietenLijst.Add(onhandigePiet);
                    cadeauTypes.Add(CadeauType.Speelgoed);
                }
                if (cadeauTypes.Contains(CadeauType.Educatief))
                {
                    onhandigePiet = new OnhandigePiet();
                    slimmePiet = new SlimmePiet();

                    pietenLijst.Add(onhandigePiet);
                    pietenLijst.Add(slimmePiet);
                    cadeauTypes.Add(CadeauType.Educatief);
                }
            }

            return pietenLijst;
        }
    }
}