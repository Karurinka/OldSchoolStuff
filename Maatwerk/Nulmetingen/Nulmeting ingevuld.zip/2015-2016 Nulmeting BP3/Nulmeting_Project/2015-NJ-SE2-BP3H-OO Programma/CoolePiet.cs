﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2015_NJ_SE2_BP3H_OO_Programma
{
    public class CoolePiet : Piet 
    {
        // Constructor
        public CoolePiet()
        {

        }

        public CoolePiet(bool iscreatief, bool kanrijmen, bool snaptcomputers)
            :base(iscreatief, kanrijmen, snaptcomputers)
        {

        }

        public override string ToString()
        {
            return "Deze piet is een coole piet";
        }

    }
}
