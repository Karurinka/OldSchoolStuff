﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2015_NJ_SE2_BP3H_OO_Programma
{
    public class Gemeente : IComparable<Gemeente>
    {
        // Fields
        private string naam;
        private int aantalkinderen;
        private int x;
        private int y;
        private string provincie;
        private string gemeente;
        private Provincie provincie1;

        // Propertys
        public string Naam
        {
            get { return naam; }
            set { naam = value; }
        }

        public int AantalKinderen
        {
            get { return aantalkinderen; }
            set { aantalkinderen = value; }
        }

        public int X
        {
            get { return x; }
            set { x = value; }
        }

        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        public string Provincie
        {
            get { return provincie; }
            set { provincie = value; }
        }

        // Constructor
        public Gemeente(string naam, string provincie, int aantalKinderen, int x, int y)
        {
            this.naam = naam;
            this.provincie = provincie;
            this.aantalkinderen = aantalKinderen;
            this.x = x;
            this.y = y;
        }

        public Gemeente(string gemeente, Provincie provincie1, int aantalkinderen, int x, int y)
        {
            this.gemeente = gemeente;
            this.provincie1 = provincie1;
            this.aantalkinderen = aantalkinderen;
            this.x = x;
            this.y = y;
        }

        // Methods
        //public int AfstandTot(Gemeente gemeente)
        //{

        //}

        /// <summary>
        /// Sorteren van het aantal kinderen.
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public int CompareTo(Gemeente other)
        {
            if (this.AantalKinderen < other.AantalKinderen)
            {
                return -1;
            }
            else if (this.AantalKinderen > other.AantalKinderen)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        public override string ToString()
        {
            string info = Naam +  " " +  Provincie + " Coördinaat X: " + X + " Coördinaat Y: " + Y + " Aantal kinderen: " + AantalKinderen;
            return info;
        }
    }
}
