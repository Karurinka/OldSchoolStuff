﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2015_NJ_SE2_BP3H_OO_Programma
{
    public class OngeldigePietException : Exception
    {
        // TODO: maak een exception met een goede omschrijving van het probleem.
        string ex = "Er is een fout opgetreden bij het aanmaken van een piet";
    }
}
