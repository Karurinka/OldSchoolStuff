﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2015_NJ_SE2_BP3H_OO_Programma
{
    public class WegwijsPiet : Piet
    {
        public bool IsWegwijs { get; private set; }
        // Constructor
        public WegwijsPiet()
        {

        }

        public WegwijsPiet(bool iscreatief, bool kanrijmen, bool snaptcomputers)
            : base(iscreatief, kanrijmen, snaptcomputers)
        {

        }



        public override string ToString()
        {
            return "Deze piet is een wegwijspiet piet";
        }

    }
}
