﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2015_NJ_SE2_BP3H_OO_Programma
{
    public class Provincie : IComparable<Provincie>
    {
        // Fields
        private string naam;
        private List<Gemeente> gemeenten = new List<Gemeente>();

        // Propertys
        public string Naam
        {
            get { return naam; }
            set { naam = value; }
        }

        public List<Gemeente> Gemeenten
        {
            get { return gemeenten; }
            set { gemeenten = value; }
        }

        // Constructor
        public Provincie(string naam)
        {
            Naam = naam;
        }

        public Provincie()
        {

        }
        
        // Methods
        /// <summary>
        /// Voegt een gemeente toe aan de lijst.
        /// </summary>
        /// <param name="gemeente"></param>
        public void VoegGemeenteToe(Gemeente gemeente)
        {
            Gemeenten.Add(gemeente);
        }

        public Gemeente ZoekGemeente(string naam)
        {
            foreach (Gemeente gemeente in Gemeenten)
            {
                if(gemeente.Equals(naam)) {
                    return gemeente;
                }
                
            }
            return null;
        }

        public override string ToString()
        {
            string info = Naam;
            return info;
        }

        /// <summary>
        /// Provincies op naam sorteren
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public int CompareTo(Provincie other)
        {
            return Naam.CompareTo(other.Naam);
        }

        public override bool Equals(object obj)
        {
            if (obj is Provincie)
            {
                Provincie b = (Provincie)obj;
                return this.naam.Equals(b.Naam);
            }
            return false;
        }
    }
}
