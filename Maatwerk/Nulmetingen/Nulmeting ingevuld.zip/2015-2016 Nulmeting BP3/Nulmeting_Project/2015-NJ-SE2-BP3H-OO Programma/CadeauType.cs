﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2015_NJ_SE2_BP3H_OO_Programma
{
    public enum CadeauType
    {
        Digitaal,
        Educatief,
        Gedicht,
        Speelgoed
    }
}
