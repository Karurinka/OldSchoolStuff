﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2015_NJ_SE2_BP3H_OO_Programma
{
    public abstract class Piet
    {
        // TODO Voorzie Piet van een Constructor en van de 3 eigenschappen.
        public bool IsCreatief { get; private set; }
        public bool KanRijmen { get; private set; }
        public bool SnaptComputers { get; private set; }

        public Piet()
        {

        }

        public Piet(bool iscreatief, bool kanrijmen, bool snaptcomputers)
        {
            this.IsCreatief = iscreatief;
            this.KanRijmen = kanrijmen;
            this.SnaptComputers = snaptcomputers;
        }

        public Boolean controlerenVaardigheden()
        {
            if (IsCreatief == true || KanRijmen == true || SnaptComputers == true)
            {

                return true;
            }
            else
            {
                return false;
            }
            // TODO Help hem door de software zo aanpasbaar mogelijk te maken voor cadeau types 
            // en Piet vaardigheden, en door een controle in te bouwen dat een Piet enkel kan 
            // aangemaakt worden als die minstens 1 vaardigheid heeft. Wat geen enkele Piet 
            // echter kan, is de vaardigheden creatief zijn combineren met een computervaardigheid.
        }

        public override string ToString()
        {
            if (IsCreatief == true)
            {
                return "Deze piet is een onhandige piet";
            }

            else if (KanRijmen == true)
            {
                return "Deze piet is een coole piet";
            }

            else if (SnaptComputers == true)
            {
                return "Deze piet is een slimme piet";
            }
            else
            {
                return base.ToString();
            }
        }

    }
}
