-- opgave 1


-- opgave 2a


-- opgave 2b


-- opgave 2c


-- opgave 2d


-- opgave 2e


-- opgave 2f

